<?php

return [
    "posted_by" => "Posted By",
    "read_more" => "Read More",
];
 