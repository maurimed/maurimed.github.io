@extends('site.layouts.master')

@section('content')


@include('site.layouts.partials.components.slider')

<!-- @include('site.layouts.partials.components.description') -->

<!-- @include('site.layouts.partials.components.tabs') -->


<!-- @include('site.layouts.partials.components.landing-form') -->

@include('site.layouts.partials.components.testimonials-1')


@include('site.layouts.partials.components.ambassadors')


<!--@include('site.layouts.partials.components.work')-->

<!--@include('site.layouts.partials.components.features')-->


<!--@include('site.layouts.partials.components.feature-cards')-->

<!--@include('site.layouts.partials.components.partners')-->
@stop