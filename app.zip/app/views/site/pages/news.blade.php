@extends('site.layouts.master')

@section('content')
<script type="text/javascript" src="http://widgets.paper.li/javascripts/sr.iframe.min.js"></script>
<script type="text/javascript">
    Paperli.PaperFrame.Show({
        domain: 'paper.li',
        pid: '848b5ba1-3056-4559-bea1-525d36ce6397'
    });

</script>
@stop