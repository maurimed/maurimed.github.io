<div class="side-menu" id="side-menu-1">

    {{ link_to_route('about.message', Lang::get('menu.about.message_from_co_founders'),[], ['class' => 'element']) }}
    {{ link_to_route('about.mission', Lang::get('menu.about.mission_and_vision'),[], ['class' => 'element']) }}
    {{ link_to_route('about.glance', Lang::get('menu.about.epro_360_at_a_glance'),[], ['class' => 'element']) }}
    {{ link_to_route('about.apart', Lang::get('menu.about.what_set_us_apart'),[], ['class' => 'element']) }}
    {{ link_to_route('about.team', Lang::get('menu.about.epro_360_team'),[], ['class' => 'element']) }}

    <!--                    <div class="parent element">-->
    <!--                        <a class="title collapsed" data-toggle="collapse" data-target="#sub-collapse-1" data-parent="#side-menu-1">Font Icons <span class="main-text-color"></span> </a>-->
    <!--                        <div id="sub-collapse-1" class="submenu collapse">-->
    <!--                            <a href="icons-font-awesome.html" class="element">Font Awesome Icons</a>-->
    <!--                            <a href="icons-lineicons.html" class="element">Font Line Icons</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
</div>