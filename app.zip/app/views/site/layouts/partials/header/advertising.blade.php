            <div class="hidden-sm hidden-xs">
                <div class="advertising collapse in">
                    <div class="clearfix">
                        <div class="info">
                            <div class="title alt-text-color medium">Corex Unique Elements Extensions</div>
                            <div class="text">
                                Soon here will be added additional elements which stand out from the basic elements but which
                                fit cool with the template design & customer needs.
                            </div>
                            <a class="close main-bg-color" data-toggle="collapse" data-target=".advertising">
                            <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <div class="variants">
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-comment"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-camera"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-shop"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-cloud"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-cd"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-graduation-cap"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-diamond"></i>
                            </div>
                            </a>
                            <a class="element">
                            <div class="inside">
                                <i class="alt-text-color icon icon-calendar"></i>
                            </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>