<header class="head-1">
@include('site.layouts.partials.header.top-bar')

<div class="container menu-bar" role="navigation">
    <div class="large-header">


        @include('site.layouts.partials.header.logo')

        @include('site.layouts.partials.header.utilities')

        @include('site.layouts.partials.header.nav-bar')


    </div>

    @include('site.layouts.partials.header.mobile')
</div>
</header>