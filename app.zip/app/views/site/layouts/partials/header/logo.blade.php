<div class="navbar-header">
    <a class="logo-box" href="/">
        <img class="img-responsive" alt="Epro 360" src="/site/img/logo.png">
    </a>
</div>