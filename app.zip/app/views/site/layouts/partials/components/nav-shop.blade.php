<div id="nav-shop" class="panel-collapse collapse">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-9 col-xs-12">
                            <div class="items">
                                <div class="item">
                                    <a class="image pull-left mgp-img" href="/site/images/product.png">
                                    <img class="img-responsive" alt="" src="/site/images/product.png">
                                    </a>
                                    <div class="text pull-left">
                                        <p><a>Lorem Ipsum Dolor consecteur </a></p>
                                        <p>$79/QUANTITY: 1</p>
                                        <h6 class="main-text-color"><a class="clear">Clear</a> <i class="fa fa-times-circle-o"></i>
                                        </h6>
                                    </div>
                                </div>
                                <div class="item">
                                    <a class="image pull-left mgp-img" href="/site/images/product.png">
                                    <img class="img-responsive" alt="" src="/site/images/product.png">
                                    </a>
                                    <div class="text pull-left">
                                        <p><a>Lorem Ipsum Dolor consecteur </a></p>
                                        <p>$79/QUANTITY: 1</p>
                                        <h6 class="main-text-color"><a class="clear">Clear</a> <i class="fa fa-times-circle-o"></i>
                                        </h6>
                                    </div>
                                </div>
                                <div class="item">
                                    <a class="image pull-left mgp-img" href="/site/images/product.png">
                                    <img class="img-responsive" alt="" src="/site/images/product.png">
                                    </a>
                                    <div class="text pull-left">
                                        <p><a>Lorem Ipsum Dolor consecteur </a></p>
                                        <p>$79/QUANTITY: 1</p>
                                        <h6 class="main-text-color"><a class="clear">Clear</a> <i class="fa fa-times-circle-o"></i>
                                        </h6>
                                    </div>
                                </div>
                                <div class="item">
                                    <a class="image pull-left mgp-img" href="/site/images/product.png">
                                    <img class="img-responsive" alt="" src="/site/images/product.png">
                                    </a>
                                    <div class="text pull-left">
                                        <p><a>Lorem Ipsum Dolor consecteur </a></p>
                                        <p>$79/QUANTITY: 1</p>
                                        <h6 class="main-text-color"><a class="clear">Clear</a> <i class="fa fa-times-circle-o"></i>
                                        </h6>
                                    </div>
                                </div>
                                <div class="item">
                                    <a class="image pull-left mgp-img" href="/site/images/product.png">
                                    <img class="img-responsive" alt="" src="/site/images/product.png">
                                    </a>
                                    <div class="text pull-left">
                                        <p><a>Lorem Ipsum Dolor consecteur </a></p>
                                        <p>$79/QUANTITY: 1</p>
                                        <h6 class="main-text-color"><a class="clear">Clear</a> <i class="fa fa-times-circle-o"></i>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-xs-12 cart">
                            <h4>CART SUBTOTAL <span class="medium"> $158 </span></h4>
                            <div class="sep"></div>
                            <a class="button striped md blue">view cart</a>
                            <a class="button solid md blue">
                            <div class="over">proceed to checkout</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>