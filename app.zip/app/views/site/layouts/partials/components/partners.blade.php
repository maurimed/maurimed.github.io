<div class="parteners carousel content">
    <div class="container">
        <div class="feed cycle-slideshow" data-cycle-carousel-fluid="true" data-cycle-fx="carousel"
            data-cycle-timeout="2000">
            <img src="/site/images/part-1.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
            <img src="/site/images/part-2.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
            <img src="/site/images/part-3.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
            <img src="/site/images/part-4.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
            <img src="/site/images/part-5.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
            <img src="/site/images/part-3.png" class="img-responsive" alt="" data-toggle="tooltip"
            title="Donec id elit non mi porta loreta et">
        </div>
        <div class="fade-l">
            <img src="/site/images/part-fade-l.png" class="over-fade" alt="">
        </div>
        <div class="fade-r">
            <img src="/site/images/part-fade-r.png" class="over-fade" alt="">
        </div>
    </div>
</div>