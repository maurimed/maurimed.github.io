            <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center main-el">
                            <h2 class="main-text-color">Lorem Ipsum Dolor Sit Amet Consecteur Adisciping Elit ! </h2>
                            <div class="divider divider-3"></div>
                            <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor
                            mauris condimentum nibh, ut fermentum
                            assa justo sit amet
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 box-2 main-el">
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-users circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>Dedicated Customer support</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-rocket circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>HTML/CSS/PHP</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-thumbs-up circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>Unlimited Layout Posibilities</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-plane circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>PSD/HTML Files Included</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 box-2 main-el">
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-users circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>Dedicated Customer support</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-rocket circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>HTML/CSS/PHP</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-thumbs-up circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>Unlimited Layout Posibilities</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="pull-left">
                                    <i class="fa fa-plane circled main-bg-color alt-text-color"></i>
                                </div>
                                <div class="text">
                                    <h4>Regular Weekly Updates</h4>
                                    <p>Donec id elit non mi porta gravida at eget metus. </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 main-el">
                            <div class="form form-1">
                                <div class="head main-text-color">
                                    Yes! Please contact me for customisation...
                                </div>
                                <div class="input-group">
                                    <input type="text" placeholder="Name *" class="form-control">
                                    <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                                </div>
                                <div class="input-group c-border-top">
                                    <input type="text" placeholder="Email *" class="form-control">
                                    <span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
                                </div>
                                <div class="textarea textarea-icon">
                                    <i class="fa fa-pencil fa-fw"></i><textarea placeholder="Message *" class="form-control"
                                    rows="4"></textarea>
                                </div>
                                <div class="btns">
                                    <a class="button solid blue sm">
                                    <div class="over">submit</div>
                                    </a>
                                    <a class="clear pull-right">
                                    Clear All <i class="fa fa-times-circle-o"></i>
                                    </a>
                                </div>
                                <div class="shadow">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>