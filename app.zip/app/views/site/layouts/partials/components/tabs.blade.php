    <div style="padding-top:0; padding-bottom:0" class="container">
        <div class="row">
            <div class="col-md-12 text-center preview-banner main-el">
                <div class="text">
                    <h2 class="main-text-color">Epro 360  </h2>
                    <div class="divider divider-3"></div>

                </div>
            </div>
            <div class="col-sm-12 main-el">
                <div class="sep-heading-container shc4 clearfix">
                    <h4 class="text-center">Five Advantages That Makes Us Unique</h4>
                  
                </div>
                <div id="d-tabs" class="tab def home-advantages">
                    <ul>
                        <li><a href="#value"><h6>Value</h6></a></li>
                        <li><a href="#opportunity"><h6>Opportunity</h6></a></li>
                        <li><a href="#self-discovery"><h6>Self-discovery</h6></a></li>
                        <li><a href="#competitive-advantage"><h6>Competitive Advantage</h6></a></li>
                        <li><a href="#global-networking"><h6>Global Networking</h6></a></li>
                    </ul>
                    <div id="value"> <p>value</p> </div>
                    <div id="opportunity"> <p>opportunity</p> </div>
                    <div id="self-discovery"> <p>self-discovery</p> </div>
                    <div id="competitive-advantage"> <p>competitive-advantage</p> </div>
                    <div id="global-networking"> <p>global-networking</p> </div>
                </div>
            </div>                    
        </div>

        <div class="col-md-12 main-el">
            <div class="sep-line"></div>
        </div>
</div>
