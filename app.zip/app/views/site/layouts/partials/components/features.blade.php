            <div id="main-features" class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 main-el">
                            <div class="gallery preview">
                                <div class="navigation">
                                    <div class="thumb">
                                        <div class="img-container">
                                            <div class="images clearfix">
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-1.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-1-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-2.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-2-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-3.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-3-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-4.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-4-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-5.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-5-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-1.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-1-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-2.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-2-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-3.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-3-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-4.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-4-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                                <div class="frame" data-toggle="tooltip" data-preview="/site/images/gallery-5.png"
                                                    title="Donec id elit non mi porta loreta et">
                                                    <div class="image">
                                                        <a class="overlay">
                                                        <i class="fa fa-search sm"></i>
                                                        </a>
                                                        <img src="/site/images/gallery-5-thumb.png" class="img-responsive" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="col-sm-6 boxes-5 clearfix main-el">
                            <div class="row item">
                                <div class="col-md-12">
                                    <div class="badge pull-left">
                                        <i class="fa fa-thumbs-up main-text-color"></i>
                                    </div>
                                    <div class="text">
                                        <h5 class="medium">Dedicated Customer Support</h5>
                                        <p>
                                        Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus
                                        ommodo, tortor mauris condimentum nibh
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row item clearfix">
                                <div class="col-md-12">
                                    <div class="badge pull-left">
                                        <i class="fa fa-cog main-text-color"></i>
                                    </div>
                                    <div class="text">
                                        <h5 class="medium">Advanced Seo Optimized</h5>
                                        <p>
                                        Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus
                                        ommodo, tortor mauris condimentum nibh
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row item clearfix">
                                <div class="col-md-12">
                                    <div class="badge pull-left">
                                        <i class="fa fa-plane main-text-color"></i>
                                    </div>
                                    <div class="text">
                                        <h5 class="medium">Regulary Weekly Updates</h5>
                                        <p>
                                        Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus
                                        ommodo, tortor mauris condimentum nibh
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row item">
                                <div class="col-xs-12">
                                    <div class="badge pull-left">
                                        <i class="fa fa-trophy main-text-color"></i>
                                    </div>
                                    <div class="text">
                                        <h4>Premium Marketing Services</h4>
                                        <p>
                                        Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus
                                        ommodo, tortor mauris condimentum nibh
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>