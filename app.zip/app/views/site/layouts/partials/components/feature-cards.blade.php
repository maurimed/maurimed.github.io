<div id="feature-cards">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-1">
                    <div class="background-overlay">
                        <div class="top">
                            <i class="fa fa-plane alt-text-color pull-left"></i>
                            <h4 class="alt-text-color light"> Advanced Seo Optimized </h4>
                        </div>
                        <p class="alt-text-color">
                        Donec id elit non mi porta gravida at eget metus.
                        sce dapibus, tellus ac cursus commodo, loretase
                        umi diam notre set alurum.
                        </p>
                        <a href="../#">
                        <div class="button light">
                            <div class="over"></div>
                            +
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-2">
                    <div class="background-overlay">
                        <div class="top">
                            <i class="fa fa-thumbs-up alt-text-color pull-left"></i>
                            <h4 class="alt-text-color light"> Dedicated User Support </h4>
                        </div>
                        <p class="alt-text-color">
                        Donec id elit non mi porta gravida at eget metus.
                        sce dapibus, tellus ac cursus commodo, loretase
                        umi diam notre set alurum.
                        </p>
                        <a href="../#">
                        <div class="button light">
                            +
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-3">
                    <div class="background-overlay">
                        <div class="top">
                            <i class="fa fa-download alt-text-color pull-left"></i>
                            <h4 class="alt-text-color light"> Dedicated User Support </h4>
                        </div>
                        <p class="alt-text-color">
                        Donec id elit non mi porta gravida at eget metus.
                        sce dapibus, tellus ac cursus commodo, loretase
                        umi diam notre set alurum.
                        </p>
                        <a href="../#">
                        <div class="button light">
                            +
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>