
@include('site.layouts.partials.landing-form')

<div class="bannercontainer">
    <div class="banner">
    
        <ul>
            <li id="slide1" data-transition="fade" data-slotamount="1">
                <img src="/site/img/sliders/slider-1.jpg" alt="">
                <div class="tp-caption caption1 title skewfromleft" data-x="center" data-voffset="-100" data-y="-20"data-speed="800" data-start="800">
                    <div class="container text-center">
                        <div class="bold text-shadow ">
                           <span class="text-bg-color"> {{ trans('home.sliders.first.text1') }} </span>
                        </div>
                    </div>
                </div>
                <div class="tp-caption caption1 title skewfromright" data-x="center" data-y="50" data-speed="800"data-start="1800">
                    <div class="container text-center" >
                        <div class="bold text-shadow">
                             <span class="text-bg-color">{{ trans('home.sliders.first.text2') }}</span>
                        </div>
                    </div>
                </div>

                <div class="tp-caption caption1 title lfb" data-x="center" data-voffset="90" data-y="120" data-speed="800" data-start="2800" >
                    <div class="container text-center" >
                        <div class="bold text-shadow">
                            <span class="text-bg-color">{{ trans('home.sliders.first.text3') }}</span>
                        </div>
                    </div>
                </div>
<!--                <div class="tp-caption caption1 title lfb" data-x="center" data-voffset="90" data-y="440" data-speed="800" data-start="3200" >-->
<!--                    <div class="container text-center" >-->
<!--                        <div class="bold ">-->
<!--                            <a href="#" title="Apply Now !" class="button md solid blue"><div class="over" style="font-size:1.8em" >Apply Now !</div></a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
            </li>
            <li id="slide1" data-transition="fade" data-slotamount="1">
                <img src="/site/img/sliders/slider-2.jpg" alt="">
                <div class="tp-caption caption1 title skewfromleft" data-x="center" data-voffset="-100" data-y="280"data-speed="800" data-start="800">
                    <div class="container text-center">
                        <div class="bold text-shadow ">
                           <span class="text-bg-color">{{ trans('home.sliders.second.text1') }}</span>
                        </div>
                    </div>
                </div>
                <div class="tp-caption caption1 title skewfromright" data-x="center" data-y="350" data-speed="800"data-start="1800">
                    <div class="container text-center" >
                        <div class="bold text-shadow">
                            <span class="text-bg-color">{{ trans('home.sliders.second.text2') }}</span>
                        </div>
                    </div>
                </div>

<!--                <div class="tp-caption caption1 title lfb" data-x="center" data-voffset="90" data-y="440" data-speed="800" data-start="2800" >-->
<!--                    <div class="container text-center" >-->
<!--                        <div class="bold ">-->
<!--                            <a href="#" title="Apply Now !" class="button md solid blue"><div class="over" style="font-size:1.8em" >Apply Now !</div></a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
            </li>
        </ul>
    </div>
</div>
