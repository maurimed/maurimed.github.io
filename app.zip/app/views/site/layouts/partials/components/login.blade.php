<div id="login" class="auth panel-collapse collapse">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4 col-xs-8 col-xs-offset-2 main-el">


                @include('sessions.login-form')

            </div>
        </div>
    </div>
</div>