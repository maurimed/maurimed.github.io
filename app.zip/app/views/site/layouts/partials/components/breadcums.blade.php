<div class="pagecrumbs testimonials-3">
    <div class="container">
            <div class="col-xs-12 ">
                <h5 class="alt-text-color text-center">{{ $title }}</h5>
            </div>
    </div>
</div>