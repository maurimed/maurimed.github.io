<div id="search" class="panel-collapse collapse">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="input-group">
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Search In
                                    <span class="caret down"></span><span class="caret up"></span></button>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">Portfolio</a></li>
                                        <li><a href="#">Events</a></li>
                                        <li><a href="#">Shop</a></li>
                                        <li><a href="#">Pages</a></li>
                                    </ul>
                                </div>
                                <!-- /btn-group -->
                                <input type="text" class="form-control">
                                <span class="input-group-btn">
                                <button class="btn btn-default button solid blue" type="button">
                                <span class="over">
                                <i class="fa fa-search"></i>
                                </span>
                                </button>
                                </span>
                            </div>
                            <!-- /input-group -->
                        </div>
                    </div>
                </div>
            </div>