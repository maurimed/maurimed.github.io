<div id="botbar">
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <p>
                &#169; Copyright 2014 - Epro 360 Global Education S.L. - All Rights reserved
                </p>
            </div>
            <div class="col-sm-5">
                <span class="socials">
                <a data-toggle="tooltip" title="Facebook" class="facebook" href="{{ Lang::get('footer.social_links.facebook') }}"> <i class="fa fa-facebook"></i> </a>
                <a data-toggle="tooltip" title="Twitter" class="twitter" href="{{ Lang::get('footer.social_links.twitter') }}"> <i class="fa fa-twitter"></i> </a>
                <a data-toggle="tooltip" title="Youtube" class="youtube" href="{{ Lang::get('footer.social_links.youtube') }}"> <i class="fa fa-youtube"></i> </a>
<!--                 <a data-toggle="tooltip" title="Dribbble" class="dribbble" href="../#"> <i
                class="fa fa-dribbble"></i> </a>
                <a data-toggle="tooltip" title="Vimeo" class="vimeo" href="../#"> <i
                class="fa fa-vimeo-square"></i> </a>
                <a data-toggle="tooltip" title="Skype" class="skype" href="../#"> <i
                class="fa fa-skype"></i> </a>
                <a data-toggle="tooltip" title="Linkedin" class="linkedin" href="../#"> <i
                class="fa fa-linkedin"></i> </a>
                <a data-toggle="tooltip" title="Pinterest" class="pinterest" href="../#"> <i
                class="fa fa-pinterest"></i> </a>
                <a data-toggle="tooltip" title="RSS" class="rss" href="../#"> <i
                class="fa fa-rss"></i> </a> -->
                </span>
            </div>
        </div>
    </div>
</div>