<!-- col -->
<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
    <h1 class="page-title txt-color-blueDark">
        <!-- PAGE HEADER -->
        <i class="fa-fw fa fa-{{ $icon }}"></i>
        {{ $title }}
        <span> {{ $subtitle }} </span>
    </h1>
</div>
<!-- end col -->