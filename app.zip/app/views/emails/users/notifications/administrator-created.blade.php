<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Epro 360</title>
</head>
<body>
<p> {{ $name }} Your temporary password is {{ $password }}</p>
</body>
</html>