<?php

return [
    "email" => "info@epro360.com",
    "phone" => "+1 (314) 269-0457",
];