<?php

return array(

	"about" => array(
		"title" => "Short about us",
		"content" => "Our Coaches and Mentors are not just simple advisors, they are important role models with track records of academic and professional excellence. They are living proof that a well-balanced, global education prepares students for life not to mention success.",
	),
	"interes_links" => "Interest links",
    "social_links" => array(
        "facebook" => "https://www.facebook.com/Epro360GlobalEducation",
        "twitter" => "https://twitter.com/Epro360info",
        "youtube" => "https://www.youtube.com/user/Epro360StudyAbroad/videos",
    )

);