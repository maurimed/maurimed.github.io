<?php


return [

    "landing_title" => "To request more info, please fill out this form and we will get in touch with you",
    "landing_text" => "Text for convince the user to download",
    "text_button" => "Send",

    "sliders" =>[
        "first" => [
            "text1" => "We make your DREAM",
            "text2" => "to study in the U.S",
            "text3" => "A REALITY!"
        ],
        "second" => [
            "text1" => "Academic and Athletic",
            "text2" => "Scholarships to study in the US"
        ],

    ]

];