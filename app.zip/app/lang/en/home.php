<?php


return array(

    "landing_title" => "To request more info, please fill out this form and we will get in touch with you",
    "landing_text" => "Text for convince the user to download",
    "text_button" => "Send",

);