<?php

return [
    "phone" => "(+593) 98 644 7648",
];