<?php


return [

    "landing_title" => "Si desease recibir más información, por favor complete el siguiente formulario y le contactaremos pronto",
    "landing_text" => "Text for convince the user to download",
    "text_button" => "Enviar",

];