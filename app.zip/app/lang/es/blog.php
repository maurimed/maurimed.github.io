<?php

return [
    "posted_by" => "Publicado por",
    "read_more" => "Leer mas",
];
 