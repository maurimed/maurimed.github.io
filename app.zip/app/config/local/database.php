<?php

return array(

	'connections' => array(

//		'mysql' => array(
//			'driver'    => 'mysql',
//			'host'      => 'localhost',
//			'database'  => 'epro',
//			'username'  => 'homestead',
//			'password'  => 'secret',
//			'charset'   => 'utf8',
//			'collation' => 'utf8_unicode_ci',
//			'prefix'    => '',
//		),

        'mysql' => [
            'driver'    => 'mysql',
            'host'      => 'localhost',
            'database'  => 'eprotest',
            'username'  => 'root',
            'password'  => 'root',
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => '',
        ]



    ),

);
