<?php

return [


	'connections' => [

//
//        'mysql' => [
//            'driver'    => 'mysql',
//            'host'      => 'localhost',
//            'database'  => 'test_epro360',
//            'username'  => 'homestead',
//            'password'  => 'secret',
//            'charset'   => 'utf8',
//            'collation' => 'utf8_unicode_ci',
//            'prefix'    => '',
//        ]

        'mysql' => [
            'driver'    => 'mysql',
            'host'      => 'localhost',
            'database'  => 'eprotest',
            'username'  => 'root',
            'password'  => 'root',
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => '',
        ]

	]
//        ********************
//*General Infomation
//********************
//Connection Name: localhost_3306
//Host Name/IP Address: localhost
//Port: 3306
//User Name: root
//Save Password: True
//
//********************
//*Advanced Infomation
//********************
//Settings Save Path: C:\Users\developer\Documents\Navicat\MySQL\servers\localhost_3306
//Encoding: 65001 (UTF-8)
//Keepalive Interval (sec): N/A
//Use MySQL character set: True
//Use Compression: False
//Auto Connect: False
//Use Advanced Connections: False
//
//********************
//*SSL Infomation
//********************
//Use SSL: False
//Use Authentication: False
//Client Key:
//Client Certificate:
//CA Certificate:
//
//********************
//*SSH Infomation
//********************
//Use SSH Tunnel: False
//Host Name/IP Address:
//Port: 22
//User Name:
//Authentication Method: Password
//Save Password: False
//
//********************
//*HTTP Infomation
//********************
//Use HTTP Tunnel: False
//Tunnel URL:
//Use password authentication: False
//User Name:
//Save Password: False
//Use certificate authentication: False
//Client Key:
//Client Certificate:
//CA Certificate:
//Use Proxy: False
//Proxy Host:
//Proxy Port: 0
//Proxy User Name:
//Proxy Save Password: False
//
//********************
//*Other Infomation
//********************
//Server Version: 5.6.17
//Protocol: 10
//Info: localhost via TCP/IP




];
