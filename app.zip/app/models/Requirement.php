<?php

class Requirement extends \Eloquent {
	protected $fillable = [];
}