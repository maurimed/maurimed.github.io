<?php

class Manager extends \Eloquent {
	protected $fillable = [];
}