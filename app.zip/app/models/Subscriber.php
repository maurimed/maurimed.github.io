<?php

class Subscriber extends \Eloquent {
	protected $fillable = ['name', 'email', 'phone'];
}