<?php

class City extends \Eloquent {

    public function state()
    {
        return $this->belongsTo('State');
    }

	protected $fillable = [];
}