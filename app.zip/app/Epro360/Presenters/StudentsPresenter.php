<?php namespace Epro360\Presenters;

use Laracasts\Presenter\Presenter;

class StudentsPresenter extends Presenter {




}