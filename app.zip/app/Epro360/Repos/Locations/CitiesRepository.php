<?php  namespace Epro360\Repos\Locations;


use City;
use State;

class CitiesRepository {

    public function getAll()
    {
        return City::with([
            'state' => function($query){
                $query->get(['id', 'name', 'country_id']);
            },
            'state.country' => function($query){
                $query->get(['id', 'name']);
            }
        ])->get(['id', 'name', 'state_id']);
    }

    public function countriesList()
    {
        return State::lists('name', 'id');
    }

    public function create($input)
    {
        $country = new State;
        $country->name = $input['name'];
        $country->country_id = $input['country_id'];
        $country->save();

    }

    public function findById($id)
    {
//        return  Administrator::with('profile')->findOrFail($id);
    }


} 