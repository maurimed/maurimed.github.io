<?php  namespace Epro360\Repos\Directors;

use Director;

/**
 * Class RequirementsRepository
 * @package Epro360\Repos\Requirements
 */
class DirectorsRepository {

    /**
     * @var
     */
//    protected $form;



    /**
     * @param $directorId
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAmbassadors($directorId)
    {
        return Director::with(['ambassadors.students'])->find($directorId);
    }








} 