<?php  namespace Epro360\Repos\Users;

use Administrator;
use Ambassador;
use Director;
use Epro360\Mailers\UserMailer;
use Epro360\Services\ImageService;
use Hash;
use Input;
use Laracasts\Validation\FormValidationException;
use Mail;
use Redirect;
use Str;
use Student;
use User;
use Epro360\Forms\ProfileEditForm as ProfileForm;

class UserRepository {

    protected $profileForm;

    protected $imageService;

    protected $userMailer;

    function __construct(ProfileForm $profileForm, ImageService $imageService, UserMailer $userMailer )
    {

        $this->profileForm = $profileForm;

        $this->imageService = $imageService;

        $this->userMailer = $userMailer;

    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAll()
    {
        return User::with('userable')->get();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAdmins()
    {
        return Administrator::with(['profile', 'creator' => function($query)
        {
            $query->get(['username', 'id']);
        },'city', 'city.state.country'])->get();
    }


    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getStudents()
    {
        return Student::with('profile')->get();
    }


    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAmbassadors()
    {
        return Ambassador::with('profile')->get();
    }


    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getDirectors()
    {
        return Director::with('profile')->get();
    }

    /**
     * @param $username
     * @return mixed
     */
    public function findByUsername($username)
    {
        return $user = User::whereUsername($username)->with(['userable'])->firstOrFail();
    }

    /**
     * @param $id
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|static
     */
    public function findById($id)
    {
        return  User::with('userable')->findOrFail($id);
    }

    /**
     * @param $adminId
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|static
     */
    public function findByAdminId($adminId)
    {
        return Administrator::with('profile')->findOrFail($adminId);
    }


    /**
     * @param $adminId
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|static
     */
    public function findByAmbassadorId($adminId)
    {
        return Ambassador::with('profile')->findOrFail($adminId);
    }


    /**
     * @param $input
     * @param $userId
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|static
     */
    public function update($input, $userId)
    {

        $user = $this->findById($userId);

        $input = $this->makeUsername($input, $user);

        $this->makePassword($input, $user);

        $this->validate($input);

        if($input['zip'] != '')
            $user->userable->city_id = $input['zip'];
        $user->userable->firstname = $input['firstname'];
        $user->userable->lastname = $input['lastname'];

        if(Input::hasFile('image'))
            $this->imageService->profileImage($input, $user);

        $user->userable->update($input);
        $user->save();

        return $user;
    }

    public function create($modelInfo, $userInfo, $model)
    {

        $password = str_random(15);

        // Create user
        $user = User::create($userInfo);

        // Create model
        $userType = new $model;
        $userType->firstname = $modelInfo['firstname'];
        $userType->lastname = $modelInfo['lastname'];
        $userType->created_by = \Auth::user()->id;
        $userType->save();

        // Link the model to an user profile
        $user->userable_id = $userType->id;
        $user->userable_type = $model;
        $user->email =  $userInfo['email'];
        $user->username = Str::slug( $userInfo['email'] );
        $user->password = Hash::make($password);

        // Save the user profile
        $user->save();

        $this->userMailer->accountCreated($user, strtolower($model), $password );

        return $userType;

    }

    /**
     * @param $user
     * @return mixed
     */
    public function delete($user)
    {
        $user->profile->delete();

        return $user->delete();
    }


    /**
     * @param $input
     * @param $user
     * @return array
     */
    private function makeUsername($input, $user)
    {
        if ($user->username == $input['username'])
        {
            $input = array_except($input, array('username'));

            return $input;
        }
        else
        {
            $user->username = $input['username'];

            return $input;
        }
    }

    /**
     * @param $input
     * @param $user
     */
    private function makePassword($input, $user)
    {
        if ($input['password'] != '')
        {
            $user->password = \Hash::make($input['password']);
            return $input;

        }

        return $input;
    }



    /**
     * @param $input
     */
    private function validate($input)
    {
        try
        {
            $this->profileForm->validate($input);

        } catch (FormValidationException $e)
        {
            return Redirect::back()->withInput()->withErrors($e->getErrors())->withDangerMessage('There were validation errors');
        }
    }






} 