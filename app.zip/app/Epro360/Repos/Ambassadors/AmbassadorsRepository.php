<?php  namespace Epro360\Repos\Ambassadors;


//use Ambassador;

class AmbassadorsRepository {


//    public function getAll()
//    {
//        return Ambassador::with('profile')->get();
//    }
//
//    public function findUserByAmbassadorId($ambassador_id)
//    {
//        return Ambassador::with('profile')->findOrFail($ambassador_id);
//    }



} 