<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateZipsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('zips', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('code');
			$table->integer('city_id');
			$table->string('city');
            $table->decimal('lat', 8, 6);
            $table->decimal('lng', 10, 6);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('zips');
	}

}
